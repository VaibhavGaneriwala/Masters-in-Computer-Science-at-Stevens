import java.io.*;
import java.util.*;

// Name: Vaibhav Ganeriwala

public class TextSwap {

    private static String readFile(String filename, int chunkSize) throws Exception {
        File file = new File(filename);
	    if (file.length() % chunkSize!=0){ 
            throw new Exception("File size must be a multiple of the chunk size."); 
        }
        String line;
        StringBuilder buffer = new StringBuilder();
        BufferedReader br = new BufferedReader(new FileReader(file));
        while ((line = br.readLine()) != null){
            buffer.append(line);
        }
        br.close();
        return buffer.toString();
    }

    private static Interval[] getIntervals(int numChunks, int chunkSize) {
        int start = 0;
        int end = chunkSize - 1;
        
        Interval[] intervals = new Interval[numChunks];
        for (int i = 0; i < numChunks; i++) {
            intervals[i] = new Interval(start, end);
            start += chunkSize;
            end += chunkSize;
        }
        return intervals;
    }

    private static List<Character> getLabels(int numChunks) {
        Scanner scanner = new Scanner(System.in);
        List<Character> labels = new ArrayList<Character>();
        int endChar = numChunks == 0 ? 'a' : 'a' + numChunks - 1;
        System.out.printf("Input %d character(s) (\'%c\' - \'%c\') for the pattern.\n", numChunks, 'a', endChar);
        for (int i = 0; i < numChunks; i++) {
            labels.add(scanner.next().charAt(0));
        }
        scanner.close();
        return labels;
    }

    private static char[] runSwapper(String content, int chunkSize, int numChunks) {
        List<Character> labels = getLabels(numChunks);
        Interval[] intervals = getIntervals(numChunks, chunkSize);
        Interval[] newOrderedIntervals = new Interval[numChunks];
        char[] buffer = new char[content.length()];
        Thread[] threads = new Thread[numChunks];
        for (int i = 0; i < numChunks; i++) {
            int sourceIndex = labels.get(i) - 'a';
            int targetIndex = i;
            int offset = i * chunkSize;
            newOrderedIntervals[targetIndex] = intervals[sourceIndex];
            threads[targetIndex] = new Thread(new Swapper(newOrderedIntervals[targetIndex], content, buffer, offset));
            threads[targetIndex].start();
        }

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                System.out.println("Thread interrupted.");
            }
        }
        return buffer;
    }

    private static void writeToFile(String contents, int chunkSize, int numChunks) throws Exception {
        char[] buff = runSwapper(contents, chunkSize, numChunks);
        PrintWriter writer = new PrintWriter("output.txt", "UTF-8");
        writer.print(buff);
        writer.close();
    }

     public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java TextSwap <chunk size> <filename>");
            return;
        }
        String contents = "";
        int chunkSize = Integer.parseInt(args[0]);
        String filename = args[1];
        try {
            File file = new File(filename);
            if (!file.exists()) { // Check if file exists
                throw new Exception("File not found: " + filename);
            }
            int numChunks = (int) file.length() / chunkSize;
            if (numChunks > 26){
                System.out.println("Chunk Size too small");
                return;
            }
            contents = readFile(filename,chunkSize);
            writeToFile(contents, chunkSize, numChunks);
        } catch (Exception e) {
            System.err.println("Error" + e.getMessage());
        }
    }
}